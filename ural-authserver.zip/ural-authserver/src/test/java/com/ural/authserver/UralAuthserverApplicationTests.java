package com.ural.authserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UralAuthserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
